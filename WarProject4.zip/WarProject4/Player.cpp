/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Player.cpp
 * Author: john
 * 
 * Created on November 6, 2017, 7:44 AM
 */

#include "Player.h"

Player::Player(vector<Card*> c) {
    
    
    
    for(int i = 0; i< c.size(); i++){
        
        cards.push_back(c[i]);
        
    }
    
}

Player::Player(const Player& orig) {
}

Player::~Player() {

}

bool Player::hasNotWon(int player){
    //cout<<player<<": "<<cards.size()<<" "<<discard.size()<<endl;
    return (cards.size() + discard.size()) < 52;
    
}

vector<Card*> Player::getCards(){
   
    return cards;
}

vector<Card*> Player::getDiscard(){
    return discard;
}
void Player::setCards(vector<Card*> c){
    
    while(!cards.empty()){
        cards.pop_back();
    }
    
    cards.resize(0);
    for(int i = 0; i<c.size(); i++){
        cards.push_back(c.at(i));
    }
   
 
    
}
void Player::setDiscard(vector<Card*> c){
    while(!discard.empty()){
        discard.pop_back();
    }
    discard.resize(0);
    for(int i = 0; i<c.size(); i++){
        discard.push_back(c.at(i));
    }
}

void Player::cycle(){
    
    for(int i = 0; i<discard.size(); i++){
        
        cards.push_back(discard[i]);
        
    }
    while(!discard.empty()){
        discard.pop_back();
    }
    
    
    
}

void Player::debug(){
    for(int i = 0; i< cards.size(); i++){
        cards[i]->debug();
    }
}