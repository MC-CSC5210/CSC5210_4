/* 
 * File:   Lamp.cpp
 * Authors: Thomas Kelley, John Wyeth, Pat Langille
 * 
 * Created on November 9, 2017, 8:11 PM
 */

/**
 * some of this code was written by Christopher Stuetzle
 */
#include <SFML/System/Time.hpp>

#include "Lamp.h"

Lamp::Lamp()
{
    assert( false && "Do not use the default Lamp constructor.");
}

Lamp::Lamp(vec3 pos)
{
    Position = pos;
    
    setDefaults();
}

void Lamp::setDefaults()
{
    Yaw = PI;
    Pitch = 0.0; // Look directly down the z-axis to start
    MouseSpeed = 0.1f;
    Speed = 10.f;
    RotationSpeed = 0.01f;
}


// This function returns the View matrix, based on the position, up vector,
//   and look-at position.
// Pre:
// Post: 

mat4 Lamp::getViewMatrix()
{
    glm::vec3 look = Position + getLightVector();
    glm::vec3 up = calculateUpVector();
    
    return glm::lookAt(Position, look, up);
}

// This function sets the position to the argument _pos
// Pre:
// Post:

void Lamp::setPosition(vec3 _pos)
{
    Position = _pos;
}

// This function sets the position to the argument _pos
// Pre:
// Post:

void Lamp::setPosition(float x, float y, float z)
{
    Position = vec3(x, y, z);
}

// Return the current position of the camera
// Pre:
// Post:

vec3 Lamp::getPosition()
{
    return Position;
}

// Return the current mouse speed
// Pre:
// Post:

float Lamp::getMouseSpeed()
{
    return MouseSpeed;
}

// This function updates the local deltaTime variable
// Pre:
// Post:

void Lamp::setDeltaTime(double dt)
{
    deltaTime = dt;
}

/************************
 ** MOVEMENT FUNCTIONS **
 ***********************/

// This function adjusts the camera position by dX and dY
// Pre:
// Post:

void Lamp::moveLamp(float dX, float dY)
{
    Position += glm::vec3(dX * deltaTime * Speed, dY * deltaTime * Speed, 0);
}


// This function calculates and returns the view direction
// Pre:
// Post:

glm::vec3 Lamp::getLightVector()
{
    glm::vec3 direction(
            cos(Pitch) * sin(Yaw),
            sin(Pitch),
            cos(Pitch) * cos(Yaw)
            );

    direction = glm::normalize(direction);
    return direction;
}

glm::vec3 Lamp::calculateUpVector()
{
    return glm::normalize(glm::cross(getRightVector(), getLightVector()));
}

// This function returns the vector looking directly to the right of the camera
//   Since we're not changing the vertical component when moving 
//   (we're not ever rotating the 'roll' component), Y is 0
// Pre:
// Post:

glm::vec3 Lamp::getRightVector()
{
    glm::vec3 right = glm::vec3(
            sin(Yaw - PI / 2.0f),
            0,
            cos(Yaw - PI / 2.0f)
            );
    right = glm::normalize(right);
    return right;
}




