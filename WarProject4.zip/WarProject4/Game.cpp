/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Game.cpp
 * Author: john
 * 
 * Created on November 6, 2017, 8:46 AM
 */

#include "Game.h"

Game::Game() {
    deck = new Deck(52);
    //deck->shuffle();
    vector<Card*> p1;
    vector<Card*> p2;
    for(int i = 0; i<26; i++){
        p1.push_back(deck->getCards()[i]);
    }
    for(int i = 26; i<52; i++){
        p2.push_back(deck->getCards()[i]);
    }
    playerOne = new Player(p1);
    playerTwo = new Player(p2);
    printf("Player1:\n");
    playerOne->debug();
    printf("\nPlayer2:\n");
    playerTwo->debug();
    gameLoopCheck();
    
}

Game::Game(const Game& orig) {
}

Game::~Game() {
      
}


bool Game::gameLoopCheck(){
    //plan is to change to if staement to be called when n is pressed once event handler implemented
    if((playerOne->hasNotWon(1)) && (playerTwo->hasNotWon(2))){
        
      
        vector<Card*> cardsOne = playerOne->getCards();
        vector<Card*> cardsTwo = playerTwo->getCards();
        vector<Card*> discardOne = playerOne->getDiscard();
        vector<Card*> discardTwo = playerTwo->getDiscard();
       
        Card* backOne = cardsOne.back();
        Card* backTwo = cardsTwo.back();
        cardsOne.pop_back();
        cardsTwo.pop_back();
        playerOne->setCards(cardsOne);
        playerTwo->setCards(cardsTwo);
        
        stack.push_back(backOne);
        stack.push_back(backTwo);
        
       
       if((stack.at(stack.size()-2)->getValue() != stack.at(stack.size()-1)->getValue())){ 
       
            if(isVictor(backOne, backTwo)){
                 for(int i = 0; i<stack.size(); i++){
                    discardOne.push_back(stack.at(i));
                 }
                 while(!stack.empty()){
                 stack.pop_back();
                 }
            }
            else{
                 for(int i = 0; i<stack.size(); i++){
                    discardTwo.push_back(stack.at(i));
                }
               while(!stack.empty()){
               stack.pop_back();
             }
            }
        }
     
     
       
        playerOne->setDiscard(discardOne);
        playerTwo->setDiscard(discardTwo);
        discardOne = playerOne->getDiscard();
        discardTwo = playerTwo->getDiscard();
        
        if(cardsOne.empty() && !discardOne.empty()){
            
            playerOne->cycle();
        
        }
        
        if(cardsTwo.empty() && !discardTwo.empty()){
            
            playerTwo->cycle();
        
        }
        
       
        return true;
        
    }
    
    return false;
    
}


bool Game::isVictor(Card* c1, Card* c2){
  return c1->getValue() > c2->getValue();   
}



