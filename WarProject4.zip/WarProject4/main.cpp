/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: john
 *
 * Created on November 6, 2017, 7:21 AM
 */

#include <cstdlib>
#include "Game.h"
using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {
    Game* game = new Game();
    return 0;
}

