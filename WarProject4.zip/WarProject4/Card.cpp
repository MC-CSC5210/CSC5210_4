/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Card.cpp
 * Author: john
 * 
 * Created on November 6, 2017, 7:44 AM
 */

#include "Card.h"

Card::Card(int v, int s) {
    
    value = v;
    
    
  
    stringstream ss;
    ss<<(v+1);
    
    pngFile += "_of_";
    
    
    if(s<13){
            suite = 'H';
            pngFile += "hearts.png";
    }
    else if(s<26){
            suite = 'C';
            pngFile += "clubs.png";
    }
    else if(s<39){
            suite = 'D';
            pngFile += "diamonds.png";
    }
    else if(s<52){
            suite = 'S';
            pngFile += "spades.png";
            
        
    }
    
    pngFile = ss.str() + pngFile;
    
}



Card::~Card() {
}

void Card::debug(){
    cout<<pngFile<<endl;
}
int Card::getValue(){
    
    return value;
    
}

int Card::getSuite(){
    switch(suite){
        case 'H':
            return 12;
            break;
        case 'C':
            return 25;
            break;
        case 'D':
            return 38;
            break;
        case 'S':
            return 51;
            break;
        
        
        
    }
}