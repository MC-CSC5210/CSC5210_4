/* 
 * File:   Card.cpp
 * Author: john
 * Modified by Pat Langille
 * 
 * Created on November 6, 2017, 7:44 AM
 */

#include "Card.h"

Card::Card(int v, int s) {
    
    value = v;
    
    pngFile = "";
  
    stringstream ss;
    ss<<(v+2);
    
    pngFile += "_of_";
    
    
    if(s<13){
            suit = 'H';
            pngFile += "hearts.png";
    }
    else if(s<26){
            suit = 'C';
            pngFile += "clubs.png";
    }
    else if(s<39){
            suit = 'D';
            pngFile += "diamonds.png";
    }
    else if(s<52){
            suit = 'S';
            pngFile += "spades.png";
            
        
    }
    
    pngFile = ss.str() + pngFile;
    string fileName = "cards/" + pngFile;
    //creates card Texture
    tex = new Texture(fileName);
}



Card::~Card() {
}

void Card::debug(){
    cout<<pngFile<<endl;
}
int Card::getValue(){
    
    return value;
    
}

int Card::getSuit(){
    switch(suit){
        case 'H':
            return 12;
            break;
        case 'C':
            return 25;
            break;
        case 'D':
            return 38;
            break;
        case 'S':
            return 51;
            break;
        
        
        
    }
}

/**
 * Description: draws each face and side of the card
 * @param s - Shader
 */
void Card::draw(Shader* s){
    for(int i = 0; i < 6; i++){
        prism[i]->draw(s);
    }
}

/**
 * Description: creates the card model out of 6 rectangles
 * @param _a
 * @param _b
 * @param _c
 * @param _d
 */
void Card::setVertices(vec3 _a, vec3 _b, vec3 _c, vec3 _d){
    prism.clear();
    //creates the face of the card
    Rectangle* r = new Rectangle(_a, _b, _c, _d, tex);
    //pushes the face onto the vector
    prism.push_back(r);
    //creates a texture for the back of the card
    Texture* t = new Texture("back_of_card.png");
    //creates the back and sides of the card
    r = new Rectangle(vec3(_a.x, _a.y, _a.z + 0.0001f), vec3(_b.x, _b.y, _b.z + 0.0001f),
            vec3(_c.x, _c.y, _c.z + 0.0001f), vec3(_d.x, _d.y, _d.z + 0.000f), tex);
    prism.push_back(r);
    r = new Rectangle(_a, _b, vec3(_a.x, _a.y, _a.z + 0.0001f), vec3(_b.x, _b.y, _b.z + 0.0001f), tex);
    prism.push_back(r);
    r = new Rectangle(_a, _c, vec3(_a.x, _a.y, _a.z + 0.0001f), vec3(_c.x, _c.y, _c.z + 0.0001f), tex);
    prism.push_back(r);
    r = new Rectangle(_c, _b, vec3(_c.x, _c.y, _c.z + 0.0001f), vec3(_b.x, _b.y, _b.z + 0.0001f), tex);
    prism.push_back(r);
    r = new Rectangle(_c, _d, vec3(_c.x, _c.y, _c.z + 0.0001f), vec3(_d.x, _d.y, _d.z + 0.0001f), tex);
    prism.push_back(r);
}

/**
 * Description: sets the texture to the given texture
 * @param t
 */
void Card::setTexture(Texture* t){
    tex = t;
}