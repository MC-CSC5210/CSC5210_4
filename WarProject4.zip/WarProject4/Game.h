/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Game.h
 * Author: john
 *
 * Created on November 6, 2017, 8:46 AM
 */

#ifndef GAME_H
#define GAME_H
#include "Player.h"
class Game {
public:
    Game();
    Game(const Game& orig);
    void init();
    bool gameLoopCheck();
    bool isVictor(Card* c1, Card* c2);
    virtual ~Game();
    Deck* getMainDeck();
    void setMainDeck(vector<Card*> d);
    Player* getPlayerOne();
    Player* getPlayerTwo();
   
private:
    Player* playerOne;
    Player* playerTwo;
    vector<Card*> stack;
    Deck* deck;
};

#endif /* GAME_H */

