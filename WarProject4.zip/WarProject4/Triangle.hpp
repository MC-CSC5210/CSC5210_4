/**
 * This code was written by Christopher Stuetzle
 * Modified by Pat Langille
 */
#ifndef _TRIANGLE_H_
#define _TRIANGLE_H_

/*************************
 *** GRAPHICS INCLUDES ***
 ************************/
#include <GL/glew.h>
#include <SFML/Graphics.hpp>
#include <SFML/OpenGL.hpp>
#include <glm/vec3.hpp>
#include "Shader.hpp"

using glm::vec3;
using glm::vec4;

class Triangle
{
public:

    Triangle(vec3, vec3, vec3, GLfloat[3]);

    // The draw function
    void draw(Shader*, Texture*);
    
    // Set the colors
    void setFillColor( vec3 );
    void setBorderColor( vec3 );

private:
    vec3 a;
    vec3 b;
    vec3 c;

    // The VAO and VBO
    GLuint VAO;
    GLuint VBO;
    
    
};





#endif