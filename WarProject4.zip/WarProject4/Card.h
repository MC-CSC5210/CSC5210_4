/* 
 * File:   Card.h
 * Author: john
 * Modified by Pat Langille
 *
 * Created on November 6, 2017, 7:44 AM
 */

#ifndef CARD_H
#define CARD_H

#include <stdio.h>
#include <iostream>
#include <sstream>
#include <glm/glm.hpp>
#include "Shader.hpp"
#include "Texture.hpp"
#include "DrawableObject.h"
#include "Rectangle.h"


using glm::vec3;

using namespace std;

class Card : public DrawableObject{
public:
    Card(int value, int suite, vec3, vec3, vec3, vec3);
    int getValue();
    int getSuit();
    void debug();
    virtual ~Card();
    
    void draw(Shader*);
    void setTexture(Texture*);
private:
    int value;
    char suit;
    std::vector<Rectangle*> prism;
    string pngFile;
};

#endif /* CARD_H */

