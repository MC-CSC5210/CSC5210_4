/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Player.h
 * Author: john
 *
 * Created on November 6, 2017, 7:44 AM
 */

#ifndef PLAYER_H
#define PLAYER_H
#include "Card.h"
#include "Deck.h"
#include <vector>
using namespace std;
class Player {
public:
    Player(vector<Card*> c);
    Player(const Player& orig);
    
    vector<Card*> getDiscard();
    vector<Card*> getCards();
    void setCards(vector<Card*> cards);
    void setDiscard(vector<Card*> cards);
    void debug();
    void cycle();
    bool hasNotWon(int player);
    virtual ~Player();
private:
    vector<Card*> cards;
    vector<Card*> discard;
    
   
   
};

#endif /* PLAYER_H */

