/* 
 * File:   Player.h
 * Author: john
 *
 * Created on November 6, 2017, 7:44 AM
 */

#ifndef PLAYER_H
#define PLAYER_H
#include "Card.h"
#include "Deck.h"
#include <vector>
using namespace std;
class Player {
public:
    Player(vector<Card*> c, float, float, float, float);
    Player(const Player& orig);
    
    vector<Card*> getDiscard();
    vector<Card*> getCards();
    void setCards(vector<Card*> cards);
    void setDiscard(vector<Card*> cards);
    void debug();
    void cycle();
    bool hasNotWon(int player);
    virtual ~Player();
private:
    vector<Card*> cards;
    vector<Card*> discard;
    float v1x, v1y, v2x, v3y;
   
};

#endif /* PLAYER_H */

