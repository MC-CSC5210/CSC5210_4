/* 
 * File:   Rectangle.h
 * Author: Pat Langille
 *
 * Created on November 1, 2017, 8:14 PM
 */

#ifndef RECTANGLE_H
#define RECTANGLE_H

#include <glm/glm.hpp>
#include "Shader.hpp"
#include "Texture.hpp"
#include "Triangle.hpp"
#include "DrawableObject.h"


using glm::vec3;

class Rectangle : public DrawableObject {
public:
    Rectangle(vec3, vec3, vec3, vec3, Texture*);

    void draw(Shader*);
    
    void setTexture(Texture*);
    float getZ();
private:

    Triangle* t1;
    Triangle* t2;
    Texture* tex;
};

#endif /* RECTANGLE_H */

