/* 
 * File:   Lamp.h
 * Authors: Thomas Kelley, John Wyeth, Pat Langille
 *
 * Created on November 9, 2017, 8:11 PM
 */

#ifndef LAMP_H
#define LAMP_H

#include <fstream>
#include <iostream>
#include <glm/glm.hpp>                  // Used for the GLM math library
#include <glm/gtc/matrix_transform.hpp>	// Used for the GLM math library
#include <cmath>

using std::cerr;
using std::endl;
using namespace glm;


// This is our Camera class to manage user movement in our 3D scene

class Lamp
{
public:

    Lamp();
    Lamp(vec3);

    // Functions to get and set the view and projection matrices based on camera
    mat4 getViewMatrix();

    // Other getters and setters
    void setPosition(vec3);
    void setPosition(float, float, float);
    vec3 getPosition();
    //   coordinates
    void moveLamp(float, float);

    glm::vec3 getRightVector();
    glm::vec3 getLightVector();
    glm::vec3 calculateUpVector();


protected:

    mat4 ProjectionMatrix; // The camera's projection matrix
    vec3 Position; // The camera's position
};

#endif /* LAMP_H */

