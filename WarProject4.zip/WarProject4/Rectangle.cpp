/* 
 * File:   Rectangle.cpp
 * Author: Pat Langille
 * 
 * Created on November 1, 2017, 8:14 PM
 */

#include "Rectangle.h"

Rectangle::Rectangle(vec3 _a, vec3 _b, vec3 _c, vec3 _d, Texture* t) {
    
    GLfloat texs1[] = {0.0f, 0.0f, 1.0f, 0.0f, 0.0f, 1.0f};
    GLfloat texs2[] = {1.0f, 0.0f, 0.0f, 1.0f, 1.0f, 1.0f};
    t1 = new Triangle(_a, _b, _c, texs1);
    t2 = new Triangle(_b, _c, _d, texs2);
    tex = t;
}

Rectangle::draw(Shader* s){
    t1->draw(s, tex);
    t2->draw(s, tex);
}



