/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Deck.h
 * Author: john
 *
 * Created on November 6, 2017, 7:44 AM
 */

#ifndef DECK_H
#define DECK_H
#define NUM_CARDS 52
#define MAX_CARDS 104
#include <stdlib.h> 
#include <time.h>
#include <vector>
#include "Card.h"

using namespace std;
class Deck {
public:
    Deck(int cards);
    Deck(const Deck& orig);
    void shuffle();
    void debug();
   
    vector<Card*> getCards();
    Card play();
    virtual ~Deck();
private:
    vector<Card*> cards;
};

#endif /* DECK_H */

