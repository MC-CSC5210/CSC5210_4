/* 
 * File:   Score.h
 * Author: Patrick Langille
 *
 * Created on November 10, 2017, 4:24 PM
 */

#ifndef SCORE_H
#define SCORE_H

#include <stdio.h>
#include <iostream>
#include <sstream>
#include <glm/glm.hpp>
#include "Shader.hpp"
#include "Texture.hpp"
#include "Rectangle.h"
#include "DrawableObject.h"

using namespace std;

class Score : public DrawableObject {
public:
    Score(vec3, vec3, vec3, vec3, Texture*);
    
    void setNumCards(int);
    int getNumCards();
    void updateScore();
    
    void draw(Shader*);
    void setTexture(Texture*);
private:
    int numCards;
    Texture* tex;
    Texture* scoreTex1;
    Texture* scoreTex10;
    Rectangle* scoreRec1;
    Rectangle* scoreRec10;
    Rectangle* playerRec;

};

#endif /* SCORE_H */
