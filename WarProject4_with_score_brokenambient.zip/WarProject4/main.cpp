/*
 Created by Christopher Stuetzle (2017) 
 Modified by John Wyeth, Thomas Kelley, and Pat Langille
 */

#include <iostream>
#include <cstdio>

// User Includes
#include "SFMLApplication.h"
#include "Shader.hpp"

#include "Camera.h"
#include "glm/glm.hpp"
#include "Card.h"
#include "Game.h"
#include "Lamp.h"
#include "AmbientLight.hpp"
#include "Score.h"

using namespace std;

// Window information
GLuint winHeight = 1080;
GLuint winWidth = 1920;

int reversed = 0;
int count = 0;
// The current mouse position
double deltaX, deltaY;
bool lButtonDown;
bool rButtonDown;
vec2 mousePos;

// The one tetrahedron
vector<DrawableObject*> objects;
vector<DrawableObject*> store;
DrawableObject* selected;
Shader* s_1;
Shader* s_2;
Camera* c;
Light* ambient;
Score* player1Score;
Score* player2Score;
Texture* t;

SFMLApplication newApplication;

Game* game;
Card* card;

void updateScene(){
    
    for(int i = 0; i < game->getPlayerOne()->getCards().size(); i++){
        newApplication.addDrawableObject(game->getPlayerOne()->getCards().at(i));
    }
    for(int j = 0; j < game->getPlayerTwo()->getCards().size(); j++){
        newApplication.addDrawableObject(game->getPlayerTwo()->getCards().at(j));
    }
    for(int k = 0; k < game->getPlayerOne()->getDiscard().size(); k++){
        
        newApplication.addDrawableObject(game->getPlayerOne()->getDiscard().at(k));
    }
    for(int m = 0; m < game->getPlayerTwo()->getDiscard().size(); m++){
        
        newApplication.addDrawableObject(game->getPlayerTwo()->getDiscard().at(m));
    }
    player1Score->setNumCards((game->getPlayerOne()->getCards().size()) + (game->getPlayerOne()->getDiscard().size()));
    player2Score->setNumCards((game->getPlayerTwo()->getCards().size()) + (game->getPlayerTwo()->getDiscard().size()));
    newApplication.addDrawableObject(player1Score);
    newApplication.adddrawableObject(player2Score);
}
// Init function to set up the geometry
// Pre: None
// Post: The quads are set up

void init() {

    std::vector<Rectangle*> table;
    
    Texture* tt = new Texture("table.png");
    Rectangle* r;
    r = new Rectangle(vec3(-10, 10, 2), vec3(10, 10, 2), vec3(-10, -10, 2), vec3(10, -10, 2), tt);
    table.push_back(r);
    r = new Rectangle(vec3(-10, 10, 2), vec3(-10, -10, 2), vec3(-10, 10, 0.0), vec3(-10, -10, 0.0), tt);
    table.push_back(r);
    r = new Rectangle(vec3(-10, 10, 2), vec3(10, 10, 2), vec3(-10, 10, 0.0), vec3(10, 10, 0.0), tt);
    table.push_back(r);
    r = new Rectangle(vec3(10, 10, 2), vec3(10, -10, 2), vec3(10, 10, 0.0), vec3(10, -10, 0.0), tt);
    table.push_back(r);
    r = new Rectangle(vec3(-10, -10, 2), vec3(10, -10, 2), vec3(-10, -10, 0.0), vec3(10, -10, 0.0), tt);
    table.push_back(r);
    for(int i = 0; i < 5; i++){
    newApplication.addDrawableObject(table[i]);
    }
    t = new Texture("Player1.png");
    player1Score = new Score(vec3(-7.0f, 4.0f, 2.3f), vec3(-3.0f, 4.0f, 2.3f), vec3(-7.0f, 3.5f, 2.3f), vec3(-3.0f, 3.5f, 2.3f), t);
    t = new Texture("Player2.png");
    player2Score = new Score(vec3(3.0f, 4.0f, 2.3f), vec3(7.0f, 4.0f, 2.3f), vec3(3.0f, 3.5f, 2.3f), vec3(7.0f, 3.5f, 2.3f), t);
    newApplication.addDrawableObject(player1Score);
    newApplication.addDrawableObject(player2Score);
    // Set up the shader
    string shaders1[] = {"Texture.vert", "Texture.frag"};
    s_1 = new Shader(shaders1, true);
    // Set up the camera
    vec3 pos(0, 0, 10.0);
    GLfloat FOV = 45.0f;
    GLfloat nearPlane = 0.1f;
    GLfloat farPlane = 1000.0f;
    c = new Camera(pos, winWidth, winHeight);
    c -> setPerspective(FOV, (GLfloat) winWidth / (GLfloat) winHeight,
            nearPlane, farPlane);
    //ambient = new AmbientLight(vec3(0.0, 1.0, 0.0));
    //ambient->enable();
    //newApplication.addLight(ambient);
    game = new Game();
    game->init();
    updateScene();
    
   

}

void handleEvents(sf::Window& window) {
    sf::Event event;
  
    // While there are still events.
    while (window.pollEvent(event)) {
        if (event.type == sf::Event::Closed) {
            window.close();
        } else if (event.type == sf::Event::Resized) {
            winHeight = event.size.height;
            winWidth = event.size.width;
            glViewport(0, 0, winWidth, winHeight);
        }// Keyboard pressed
        else if (event.type == sf::Event::KeyReleased) {
            if (event.key.code == sf::Keyboard::Q) {
                window.close();
            }
        }            // Mouse button pressed  
        else if (event.type == sf::Event::MouseButtonReleased) {
            if (event.mouseButton.button == sf::Mouse::Left) {
                lButtonDown = false;
            } else if (event.mouseButton.button == sf::Mouse::Right) {
                rButtonDown = false;
            }
        } else if (event.type == sf::Event::MouseButtonPressed) {
            if (event.mouseButton.button == sf::Mouse::Left) {
                lButtonDown = true;
            } else if (event.mouseButton.button == sf::Mouse::Right) {
                rButtonDown = true;
            }
        } else if (event.type == sf::Event::MouseMoved) {
            sf::Vector2i m = sf::Mouse::getPosition();
            deltaX = mousePos.x - m.x;
            deltaY = mousePos.y - m.y;
            mousePos.x = m.x;
            mousePos.y = m.y;
            
            // If the associated button is down, make sure to 
            //   update the camera accordingly.
            if (lButtonDown) {
                c -> setViewByMouse(deltaX, deltaY);
            }
            if (rButtonDown) {
                // This is negative BECAUSE THE LOOK VECTOR IS BACKWARDS...hack
                c -> moveCamera(-deltaX, deltaY);
            }
        }
        else{
        
            if(sf::Keyboard::isKeyPressed(sf::Keyboard::N)) {
                newApplication.clearDrawables();
                vector<Card*> stack = game->getStack();
                if(!stack.empty()){
                game->populateDiscard();
                if(stack.at(stack.size()-2)->getValue() != stack.at(stack.size()-1)->getValue()){
                    
                    game->clearStack();
                    
                }
                }
                if(game->gameLoopCheck()){
                    
                   stack = game->getStack();
                    
                    updateScene();
                    cout<<"stack size "<<stack.size()<<endl;
                    if(stack.size()<3){
                        newApplication.addDrawableObject(stack.at(stack.size()-2));
                        newApplication.addDrawableObject(stack.at(stack.size()-1));
                       
                    } 
                    else{
                        for(int i = 0; i<stack.size(); i++){
                            
                           //stack.at(i)->setVertices(vec3(0.0, 3.0, stack.at(i)->getZ()), vec3(1.5, 3.0, stack.at(i)->getZ()), vec3(0.0, 0.5, stack.at(i)->getZ()), vec3(1.5, 0.5, stack.at(i)->getZ()));
                           newApplication.addDrawableObject(stack.at(i));
                           
                        }
                    }
                   
                }
            }
            if(sf::Keyboard::isKeyPressed(sf::Keyboard::L)) {
            }

        }
    }
}

int main() {
    // Set up the GLFW application
    newApplication.initializeApplication(8, 3, 3,
            "War", winWidth, winHeight);

    // Assign your callback functions (the ones you write) to the internal
    //   callbacks of the application class.
    newApplication.setCallback(handleEvents);

    // Initialize stuff local to the program
    init();
    newApplication.setShader(s_1);
    newApplication.setCamera(c);

    // Tell the application to "go"
    newApplication.initiateDrawLoop();



    return 0;
}

