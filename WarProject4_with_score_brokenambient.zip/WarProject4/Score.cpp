/* 
 * File:   Score.cpp
 * Author: Patrick Langille
 * 
 * Created on November 10, 2017, 4:24 PM
 */

#include "Score.h"

Score::Score(vec3 a, vec3 b, vec3 c, vec3 d, Texture* t) {
    numCards = 26;
    tex = t;
    scoreTex1 = new Texture("6.png");
    scoreTex10 = new Texture("2.png");
    playerRec = new Rectangle(a, b, c, d, tex);
    scoreRec1 = new Rectangle(vec3(a.x + 0.75, a.y, 2.5f), b, vec3(c.x + 0.75, c.y, 2.5f), d, scoreTex1);
    scoreRec10 = new Rectangle(vec3(a.x + 0.5, a.y, 2.5f), vec3(a.x + .74, b.y, 2.5f), vec3(c.x + 0.5, c.y, 2.5f), vec3(a.x + .74, d.y, 2.5f), scoreTex10);
}

void Score::draw(Shader* s){
    playerRec->draw(s);
    scoreRec1->draw(s);
    scoreRec10->draw(s);
}

void Score::setTexture(Texture* t){
    tex = t;
}

void Score::setNumCards(int x){
    numCards = x;
}

int Score::getNumCards(){
    return numCards;
}

void Score::updateScore(){
    string fileOne;
    string fileTwo;
    int temp = numCards / 10;
    //these two lines need to be fixed
    fileOne = to_string(numCards % 10) + ".png";
    fileTwo = to_string(temp) + ".png";
    scoreTex1 = new Texture(fileOne);
    scoreTex10 = new Texture(fileTwo);
    scoreRec1->setTexture(scoreTex1);
    scoreRec10->setTexture(scoreTex10);
}
